# Build Plan

Each milestone is one working session. Do not start the next one until the current
one's acceptance criteria pass against a real external repository.

Suggested proving grounds (public, large enough to be honest, none of them yours):
`spring-projects/spring-petclinic` for smoke tests, then something genuinely messy —
`apache/dubbo`, `sonarqube`, or any large Spring Boot app you can clone.

---

## M0 — Skeleton

Repo layout, CLI entrypoint (`arch <command> --repo <path>`), config loading, SQLite
schema and migrations, fact-writer interface, NDJSON protocol between extractors and
core, CI running tests on push.

**Done when:** `arch init --repo ./fixtures/tiny-java` creates a database with the
full schema and exits zero, and CI is green.

---

## M1 — Java facts

OpenRewrite-based extractor. Emit packages, classes, interfaces, methods, fields,
inheritance, implementations, method calls, constructor and field injection, Spring
stereotypes, REST endpoints, and JPA entity-to-table mappings.

Then the first real analysis: package-level dependency graph and cycle detection
(Tarjan).

**Done when:** running against a large public Spring Boot repo completes without
crashing, and the reported package cycles are manually verified correct on at least
three examples. Fixture tests assert exact facts for the tiny repo.

---

## M2 — History

Mine `git log --numstat --follow`. Compute per-file churn, complexity proxy
(indentation-based is fine and surprisingly good), hotspots as churn x complexity,
author concentration and bus-factor risk, and temporal coupling — pairs of files that
change in the same commit far more often than chance.

The valuable output is coupling that exists in history but **not** in the static
graph. That is logical coupling, and it is where the real damage lives.

**Done when:** the tool reports the top 20 temporally-coupled file pairs with no
static dependency, and you can explain why at least five of them are coupled.

---

## M3 — Interpretation

Community detection over the combined graph (Louvain or label propagation). Then the
LLM layer: name each cluster, describe its responsibility, and flag intent-vs-structure
mismatches (a package whose name implies one responsibility while its edges imply
another). Generate ADR candidates: observed decision, supporting evidence, question
for the team.

Every generated sentence carries citations. Enforce this in code — reject model output
that fails the citation check rather than trusting the prompt.

**Done when:** `--no-llm` still produces a full structural report, and the LLM report
on a repo you know well contains no claim you can prove false.

---

## M4 — MCP server

Expose the fact store over MCP. Tools: query dependencies, find callers, describe
module, list endpoints, find hotspots, trace data flow to a table, check for cycles
between two packages.

This is the payoff. It means an agent working in the codebase can ask structural
questions and get grounded answers.

**Done when:** Claude Code, connected to the server, correctly answers five structural
questions about a repo it has never had in context.

---

## M5 — Angular facts

TypeScript compiler API plus `@angular/compiler-cli`. Emit components, standalone
imports and NgModules, services, DI edges, routes, lazy-loaded boundaries, template
bindings, and RxJS subscription sites that never unsubscribe.

Same fact store, same analyses. Cross-stack edges where an Angular service calls a
Java endpoint — match on URL patterns, mark as inferred, not fact.

**Done when:** it runs against a large public Angular app and the DI graph is correct
on manual spot-check.

---

## M6 — Presentation

Structurizr DSL and Mermaid output for C4 levels 1–3, a static HTML report, and a
ranked findings list with severity and evidence.

**Done when:** you would show the report to your CTO without editing it first.

---

# Working method

One milestone per session. Start in plan mode, agree the approach, then execute.
`/clear` between milestones — do not let one context window span M2 and M3.

Commit at every green test, not at the end of a session.

Write the ADR before the code when the decision is architectural, after the code when
it is incidental. Either way, before the commit.

When a milestone's acceptance criteria fail, do not move the criteria. That is the
whole point of writing them down before starting.

---

# Second project: OSS contribution assistant

Separate repo, build it after M2 here. Its job is research, not authorship.

Loop: poll issue trackers via `gh` for candidate issues → filter for tractability →
clone into a scratch workspace → attempt reproduction → localize the fault → produce
a diff and a failing-then-passing test → write a briefing.

The briefing is the deliverable. You read it, understand the fix completely, rewrite
what needs rewriting, and submit as yourself. The agent never opens a pull request and
never posts a comment. That constraint is what keeps the contributions worth having.

Target list to start: ArchUnit and OpenRewrite (both feed this project directly),
Testcontainers, Micrometer, NgRx, Angular ESLint, Nx.
